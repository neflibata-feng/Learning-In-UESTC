#include <iostream>
#include <string>

int main(int argc, char* argv[]) 
{
    if (argc != 3 || std::string(argv[1]) != "--name") {
        // 如果参数数量不正确，或者第一个参数不是 "--name"，提示用户正确使用方法
        std::cerr << "用法: " << argv[0] << " --name <名字>" << std::endl;
        return 1; // 返回非零值表示程序异常退出
    }

    std::string name = argv[2]; // 获取名字
    std::cout << "hello " << name << "!" << std::endl; // 输出问候语

    return 0; 
}