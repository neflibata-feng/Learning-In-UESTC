#ifndef PLACEDATA_H
#define PLACEDATA_H
#include "objects.h"

class PlaceData
{
public:
    PlaceData()
    {
        chipRegion = CRect();
        chipRegion.ll = POS_2D(100,100);
        chipRegion.ur = POS_2D(1300,1900);
    }
    int moduleCount; 
    int MacroCount;
    int netCount;
    int pinCount;
    CRect chipRegion;
    vector<Module *> Nodes; 
    vector<Module *> Terminals;
    vector<Pin *> Pins;
    vector<Net *> Nets;
    vector<SiteRow> SiteRows;

    map<string, Module *> moduleMap; 
};

#endif